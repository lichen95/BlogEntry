export default `# 标题

- 列表
- 列表

\`\`\`
alert('Hello')
\`\`\`

[D2Admin in github](https://github.com/d2-projects/d2-admin)`
