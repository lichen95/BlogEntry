<template>
  <d2-container :filename="filename">
    <template slot="header">设置城市</template>
    <div class="inner">
      <ve-map :data="chartData" :settings="chartSettings" v-bind="pubSetting"></ve-map>
    </div>
    <template slot="footer">
      <d2-link-btn title="更多示例和文档" link="https://v-charts.js.org"/>
    </template>
  </d2-container>
</template>

<script>
import list from '@/pages/demo/charts/list/_mixin/list.js'
import mapOrigin from '@/pages/demo/charts/list/_data/beijing'
export default {
  mixins: [
    list
  ],
  data () {
    return {
      chartSettings: {
        position: 'province/beijing',
        mapOrigin
      },
      filename: __filename,
      chartData: {
        columns: ['位置', '人口'],
        rows: [
          { '位置': '延庆区', '人口': 123 },
          { '位置': '密云区', '人口': 1223 },
          { '位置': '平谷区', '人口': 2123 },
          { '位置': '海淀区', '人口': 4123 }
        ]
      }
    }
  }
}
</script>

<style lang="scss" scoped>
.inner {
  position: absolute;
  top: 20px;
  right:  20px;
  bottom: 20px;
  left: 20px;
}
</style>
