export default `<ul>
  <li class="li-1"><p>Hello</p></li>
  <li>
    <span style="color: red;">
      Hello
    </span>
  </li>
</ul>`
