export default `body {
  background-color: aliceblue;
  height: 100%;
  .my-card {
    height: 300px;
    width: 300px;
  }
}`
