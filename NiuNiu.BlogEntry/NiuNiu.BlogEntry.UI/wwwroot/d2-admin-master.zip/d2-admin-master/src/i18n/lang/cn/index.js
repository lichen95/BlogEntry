export default {
  pub: {
    pageHeader: {
      demo: '示例'
    }
  }
}
