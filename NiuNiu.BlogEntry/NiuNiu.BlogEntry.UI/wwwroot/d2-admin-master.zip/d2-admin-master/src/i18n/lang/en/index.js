export default {
  pub: {
    pageHeader: {
      demo: 'Demo'
    }
  }
}
