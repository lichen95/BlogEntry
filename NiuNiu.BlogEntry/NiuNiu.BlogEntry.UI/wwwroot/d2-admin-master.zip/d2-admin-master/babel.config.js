module.exports = {
  presets: [
    '@vue/app'
  ],
  plugins: [
    // https://babeljs.io/docs/en/babel-plugin-transform-runtime/
    '@babel/plugin-transform-runtime'
  ]
}
